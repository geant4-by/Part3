#include "Geometry.hh"

using namespace std;

//#define SU *mm

Geometry::Geometry(std::ofstream& ofsa)
{
 this->f_geom=&ofsa;
 (*f_geom) << "Hi from Geom!" << std::endl;
}

Geometry::~Geometry()
{(*f_geom) << "Bye from Geom!" << std::endl;}

G4VPhysicalVolume* Geometry::Construct()
{
        G4int ncomponents;
        G4double fraction;
	G4GeometryManager::GetInstance()->OpenGeometry();
	G4PhysicalVolumeStore::GetInstance()->Clean(); 
	G4LogicalVolumeStore::GetInstance()->Clean();
	G4SolidStore::GetInstance()->Clean();

	// Параметры мира
	world_size = 30 * m;
	nist = G4NistManager::Instance();
	world_mat = nist->FindOrBuildMaterial("G4_AIR");
	world_box = new G4Box("world_box", world_size, world_size, world_size);
	world_log = new G4LogicalVolume(world_box, world_mat, "world_log");
	world_pvpl = new G4PVPlacement(0, G4ThreeVector(0,0,0), world_log, "world_pvpl", 0, false, 0);

        Pb_mat=nist->FindOrBuildMaterial("G4_Pb");
        Si_mat=nist->FindOrBuildMaterial("G4_Si");
        
        G4Element* H = nist->FindOrBuildElement(1);
        G4Element* C = nist->FindOrBuildElement(6);
        G4Material* det_mat = new G4Material("Stilben", 0.97*g/cm3,2);
        det_mat->AddElement(H, 12);
        det_mat->AddElement(C, 14);
        
	Pb_box = new G4Box("Pb_cal", 10. * cm, 10. * cm, 1. * cm);
	Pb_log = new G4LogicalVolume(Pb_box, Pb_mat,"Pb_cal_log");
	Pb_vect = G4ThreeVector(0, 0, 0);
	G4RotationMatrix* ZERO_RM = new G4RotationMatrix(0, 0, 0);
	Pb_pvpl = new G4PVPlacement(ZERO_RM, Pb_vect, Pb_log, "Pb_cal_pvpl", world_log, 0, false, 0);
	
	Si_box = new G4Box("Si_vol", 10. * cm, 1. * cm, 1. * cm);
	Si_log = new G4LogicalVolume(Si_box, world_mat,"Si_vol_log");	
	Si_vect = G4ThreeVector(0, 0, 2.*cm);
	Si_pvpl = new G4PVPlacement(ZERO_RM, Si_vect, Si_log, "Si_vol_pvpl", world_log, 0, false, 0);
	
	Si_det_box = new G4Box("Si_det_vol", 1. * cm, 1. * cm, 1. * cm);
	Si_det_log = new G4LogicalVolume(Si_det_box, Si_mat,"Si_det_vol_log");
        Si_vect    = G4ThreeVector(0.,0.,5.*cm);
//        Si_det_pvpl = new G4PVPlacement(ZERO_RM, Si_vect, Si_det_log, "Si_det_vol_pvpl", world_log, 0, false, 0);
        Si_det_pvpl= new G4PVReplica("Si_det_vol_pvpl", Si_det_log, Si_log, kXAxis, 10, 2.*cm);

        G4double maxStep  = 10.*mm;
        G4double maxTrack = 10.*m;
        G4double maxTime  = 1.*s;
        G4double minE     = 0.001 * MeV;
        G4double minRange = 0.1 * mm;

        fStepLimit = new G4UserLimits(maxStep,maxTrack,maxTime,minE,minRange);
        Pb_log->SetUserLimits(fStepLimit);
        Si_log->SetUserLimits(fStepLimit);
        Si_det_log->SetUserLimits(fStepLimit);

        G4VisAttributes* CWhite  = new G4VisAttributes(G4Colour(1.0,1.0,1.0));
        G4VisAttributes* CGreen  = new G4VisAttributes(G4Colour(0.0,1.0,0.0));
        G4VisAttributes* CMagenta= new G4VisAttributes(G4Colour(1.0,0.0,1.0));
        Pb_log->SetVisAttributes(CGreen);
        Si_log->SetVisAttributes(CWhite);
        Si_det_log->SetVisAttributes(CMagenta);

    return new G4PVPlacement(0, G4ThreeVector(), world_log, "world_pvpl", 0, false, 0);
}
