#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 GProton->SetParticleEnergy(500. * MeV);
 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart!" << std::endl;
}

PrimaryPart::~PrimaryPart() 
{
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << std::endl;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 G4double x_position=(G4UniformRand()-0.5)*19.5*cm;
 G4double y_position=(G4UniformRand()-0.5)*1.9*cm; 
 GProton->SetParticlePosition(G4ThreeVector(x_position, y_position, -5.*cm));
 GProton->GeneratePrimaryVertex(anEvent); 
}
